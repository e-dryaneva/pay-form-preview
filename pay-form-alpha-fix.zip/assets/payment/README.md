Логотипы yandex, tbank, sber, alfa и SVG payment-sbp/card-frontside взяты из соседнего локального проекта internet-acquiring/src/assets/images. dolyami.svg — векторная реконструкция по видимому макету, требует замены на оригинальный бренд-ассет перед релизом.

Актуальные frontside.svg и dolyame.svg скопированы с рабочего стола по указанию пользователя. Отображаются 24×24 px по центру круглых подложек 40×40; белый цвет задаётся CSS, оригинальные SVG сохранены. Прежний dolyami.svg больше не используется.

Анимация кошелька: login-wallet-frames.webp — 97 исходных кадров login-wallet.webm, 24 кадра/с, сетка 10×10, кадр 160×152, lossless WebP с альфа-каналом. WalletFramesDirective рисует выбранный по currentTime кадр на canvas: Safari не зависит от поддержки прозрачного WebM. Исходное управление наведением и автопоказом сохранено.
