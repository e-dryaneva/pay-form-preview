# Assets Placeholder

This folder is reserved for:
- icons
- illustrations
- logos
- brand assets used by future Angular projects
- fonts

Current bundled fonts:
- `T-Sans`
- `Neue Haas Unica W1G`

Current bundled icons:
- `star.svg`

## Missing assets added from TUI Assets (2026-10-05)

Source: https://www.figma.com/design/R1oI4T6X9CHxl2x55MDypT/TUI-Assets

Existing DS assets take priority and are preserved unchanged. Only ten missing
resources used by the device page were added: edit, briefcase, pin-geo, hash,
receipt, at, cards, logo-dolyame, SBP and T-Pay. No bulk icon-family import.
`figma-assets.json` records their original component names and SHA-256 hashes.
Use image rendering for colored payment logos and mask rendering for monochrome icons.
